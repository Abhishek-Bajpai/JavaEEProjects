package module1.assignment;

public class ArithmeticOps {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		byte b1=50, b2=25;
		
		System.out.println("Addition of " + b1 + " and " + b2 + " is " + (b1+b2));
		System.out.println("Sustraction of " + b1 + " and " + b2 + " is " + (b1-b2));
		System.out.println("Multiplication of " + b1 + " and " + b2 + " is " + (b1*b2));
		System.out.println("Divison of " + b1 + " and " + b2 + " is " + (b1/b2));
		System.out.println("Increment Operator ++ : ");
		System.out.println("b2++ is " + b2++);
		System.out.println("++b2 is " + ++b2);

		
	}

}
