package module4.assignment.threadassignment;

public class ThreadConsumer {

	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		
		ThreadAssignment myThreadAssignment=new ThreadAssignment();
		myThreadAssignment.start();

		for(int i=1, j=1;i<=40;i++) {
			if(i%2 ==0) {
				System.out.println(j + " Even Number - " + i);
				j++;
			}
		}
	}

}
