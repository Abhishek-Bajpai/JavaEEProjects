/**
 * 
 */
package module4.assignment.interfaceassignment;

/**
 * @author Abhishek Bajpai
 *
 */
public interface MyQueueInterface {

	//Write a program to define a queue interface and 
	//have insert and delete methods in the interface. 
	//Implement these methods in a class
	
	public void insert(int value);
	public int delete();
	
}
