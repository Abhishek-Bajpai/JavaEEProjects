package module3.assignment;

final class CurrentAccount extends Account{
	
	public CurrentAccount(long accNo, String accName, double amount) {
		// TODO Auto-generated constructor stub
		super.accNumber = accNo;
		super.accName = accName;
		super.amount = amount;
		
	}


	@Override
	public void depositMonthlyInterest() {
		// TODO Auto-generated method stub
		
	}

}
