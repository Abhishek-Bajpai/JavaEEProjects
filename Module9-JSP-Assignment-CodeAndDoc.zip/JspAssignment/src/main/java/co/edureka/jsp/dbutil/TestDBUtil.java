/**
 * 
 */
package co.edureka.jsp.dbutil;

import java.sql.SQLException;

/**
 * @author Abhishek Bajpai
 *
 */
public class TestDBUtil {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		UserInfoDAO userInfoDAO = new UserInfoDAOImpl();
		try {
			//userInfo.insert(new UserInfo("cosmoleak@gmail.com", "PopEye", "David", "Warner"));
			UserInfo userInfo2 = userInfoDAO.selectByUserName("abba.ca07@gmail.com");
			System.out.println(userInfo2);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
