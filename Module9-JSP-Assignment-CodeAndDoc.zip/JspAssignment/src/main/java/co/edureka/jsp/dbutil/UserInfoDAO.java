/**
 * 
 */
package co.edureka.jsp.dbutil;

import java.sql.SQLException;


/**
 * @author Abhishek Bajpai
 *
 */
public interface UserInfoDAO {

	void create() throws SQLException;
	void insert(UserInfo user) throws SQLException;
	UserInfo selectByUserName(String userName) throws SQLException;
	
}
